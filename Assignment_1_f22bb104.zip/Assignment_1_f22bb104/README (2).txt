Compilation Command: g++ Q_1.cpp -o Q_1
Running Command:./Q_1.exe
I have a created Five functions in just a one c file
Sample input
Enter the size of array : 5
Enter the elements of array: 5 2 1 4 3
Choose one option:
1 for Sorting the array
2 for find even elements sum
3 to reverse the array
4 to find and swap the minimum element at starting of array
Output:
if user enter 1:
Sample Output:
Asscending array is : 1 2 3 4 5
Desscending array is : 5 4 3 2 1


Is user enter 2
Sample Output:
Sum of even elements is 6


If user enters 3
Sample Output:
array reverse is:
3 4 1 2 5


if user enters 4
Sample Output:
findind and swapping the minimum element to start of array
1 4 3 2 5